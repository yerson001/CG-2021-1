#ifndef RUBIK_H
#define RUBIK_H


using namespace std;

class Rubik
{
public:
    static string solve(string moves);
    static string format(string s);
};

#endif